#include <iostream>
#include <vector>
#include <memory>

//void imprimir(int a); //Cópia - C/C++
//void imprimir(int *a); //Endereço - C/C++
//void imprimir(int &a); //Endereço - C++
//void imprimir(int &&a); //Referencia RValue - C++ 11 >

using namespace std;

template <typename T>
class Vetor
{
    T *m_elements;
    unsigned int m_size;
public:
    Vetor()
    {
        //Inicializar m_elements e m_size
    }
    Vetor(const Vetor &v)
    {
        //Criar vetor com tamanho de v.m_size
        //Copiar elementos de v.m_elements
    }
    Vetor(Vetor &&v)
    {
        //Fazer jogada de pointeiros
    }
    Vetor & operator =(const Vetor &v)
    {
        //Deletar o vetor atual
        //Criar vetor com tamanho de v.m_size
        //Copiar elementos de v.m_elements
    }
    Vetor & operator =(Vetor &&v)
    {
        //Fazer jogada de pointeiros
    }
    ~Vetor()
    {
        //Limpa o vetor
    }
    void clear()
    {
        //Limpa o vetor
    }
    void push_back(const T &value)
    {
        //Cria um vetor temporario com m_size + 1
        //Copiar o vetor antigo para o temporario
        //Inserir o novo elemento no temporario
        //Deletar o vetor antigo
        //Fazer com que o vetor antigo aponte para o novo
        //Incrementar o m_size
    }
    void push_back(T &&value)
    {
        //Cria um vetor temporario com m_size + 1
        //Copiar o vetor antigo para o temporario
        //Mover o novo elemento no temporario
        //Deletar o vetor antigo
        //Fazer com que o vetor antigo aponte para o novo
        //Incrementar o m_size
    }
    unsigned int size() const
    {
        //Retorna o numero de elementos do vetor
    }
    T &operator [](unsigned int index) const
    {
        //Retorna um elemento dada uma posição
    }
};

int main()
{

    return 0;
}
