#include <iostream>
#include <data.h>
using namespace std;
int main()
{
    Data vencimento(1, 4, 2019), pagamento(1, 4, 2019);

    if(vencimento == pagamento)
        cout << "Dentro do prazo\n";
//    else if(vencimento > pagamento)
//        cout << "Atrasado\n";
//    else if(vencimento < pagamento)
//        cout << "Adiantado\n";

    return 0;
}
